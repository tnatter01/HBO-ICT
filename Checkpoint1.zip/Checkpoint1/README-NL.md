#Checkpoint 1

De opdrachten kunnen in de verschillende submodulen gevonden worden.

Vergeet niet de opdrachten te uploaden naar Blackboard! 