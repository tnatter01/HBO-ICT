#Checkpoint 1

The exercises can be found in the different submodules.

Don't forget to submit the exercises to Blackboard!
 